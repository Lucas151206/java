package evaluacion;

public class Alumno extends Persona{
	String institucion;
	Asignatura[] materias;
	
	public Alumno() {
		super();
	}
	
	public Alumno(int c, String n, String a, String ins, Asignatura[] mat ) {
		super(c, n, a);
		this.institucion = ins;
		this.materias = mat;
	}
	
	public String setInstitucion() {
		return institucion;
	}
	
	public Asignatura[] getMaterias() {
		return materias;
	}
	
	public String getInstitucion() {
		return institucion;
	}
	
	public Asignatura[] getMaterial() {
		return materias;
	}
	
	public String toString() {
		String info = super.toString() + " | Instituci�n: " + institucion;
        if (materias != null && materias.length > 0) {
            info += " | Materias: ";
            for (Asignatura a : materias)
                info += a.getNombre() + " ";
        }return info;
	}

} 
