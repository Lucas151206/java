package evaluacion;

public class Persona {
	private int cedula;
	private String nombre;
	private String apellido;

	    
	public Persona() {
	    }

	    
	public Persona(int c) {
	        setCedula(c);
	        nombre = new String("Desconocido");
	        apellido = new String("Desconocido");
	    }

	  
	    public Persona(int c, String n, String a) {
	        setCedula(c);
	        setNombre(n);
	        setApellido(a);
	    }

	   
	    public void setCedula(int c) {
	        if (c > 500000) {
	            cedula = c;
	    } else { 
	            cedula = 750000;
	    }
	   }
	   
	    public void setNombre(String n) {
	        if (n.equals("")) { 
	            System.out.println("Nombre no v�lido, se asign� Desconocido");
	            nombre = new String("Desconocido");
	        } else {
	            nombre = n;
	        }
	    }

	   
	    public void setApellido(String a) {
	        if (a.equals("")) {
	            System.out.println("Apellido no v�lido, se asign� Desconocido");
	            apellido = new String("Desconocido");
	        } else {
	            apellido = a;
	        }

	    }
	    public String toString() {
	    	return cedula + ", " + nombre + ", " + apellido;
	    }
}
