package evaluacion;

public class TestAlumno {

	public static void main(String[] args) {
		
		  
		Asignatura asignatura1 = new Asignatura(101, "Matem�ticas");
		Asignatura asignatura2 = new Asignatura(102, "Lengua");

		       
		Asignatura[] listaMaterias = { asignatura1, asignatura2 };

		
		Alumno alumno = new Alumno(75000, "Lucas", "Ca�ete", "Instituto ", listaMaterias);

		       
		System.out.println("Datos del alumno:");
		System.out.println(alumno.toString());
		    
		

	}

}
